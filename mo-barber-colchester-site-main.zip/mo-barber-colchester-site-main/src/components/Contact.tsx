import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, Phone, Mail, Clock, Star } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const Contact = () => {
  const { toast } = useToast();
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    message: ""
  });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: "Thank you for contacting us. We'll get back to you soon.",
    });
    setContactForm({ name: "", email: "", message: "" });
  };

  return (
    <section id="contact" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Get in <span className="text-barber-gold">Touch</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-inter">
            Ready to look your best? Contact Mo Barber Colchester today to schedule 
            your appointment or ask any questions about our services.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="shadow-soft border-border">
              <CardHeader>
                <CardTitle className="font-playfair text-2xl text-foreground">
                  Visit Our Barbershop
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start gap-4">
                  <MapPin className="h-6 w-6 text-barber-gold mt-1" />
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">Location</h3>
                    <p className="text-muted-foreground font-inter">
                      High Street, Colchester<br />
                      Essex, England<br />
                      CO1 1AA
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone className="h-6 w-6 text-barber-gold mt-1" />
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">Phone</h3>
                    <p className="text-muted-foreground font-inter">
                      +44 1206 123456<br />
                      <span className="text-sm">Call or text for appointments</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Mail className="h-6 w-6 text-barber-gold mt-1" />
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">Email</h3>
                    <p className="text-muted-foreground font-inter">
                      info@mobarbercolchester.co.uk<br />
                      <span className="text-sm">We'll respond within 24 hours</span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-soft border-border">
              <CardHeader>
                <CardTitle className="font-playfair text-2xl text-foreground flex items-center gap-2">
                  <Clock className="h-6 w-6 text-barber-gold" />
                  Opening Hours
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { day: "Monday", hours: "9:00 AM - 6:00 PM" },
                    { day: "Tuesday", hours: "9:00 AM - 6:00 PM" },
                    { day: "Wednesday", hours: "9:00 AM - 6:00 PM" },
                    { day: "Thursday", hours: "9:00 AM - 7:00 PM" },
                    { day: "Friday", hours: "9:00 AM - 7:00 PM" },
                    { day: "Saturday", hours: "8:00 AM - 5:00 PM" },
                    { day: "Sunday", hours: "Closed" }
                  ].map((schedule) => (
                    <div key={schedule.day} className="flex justify-between items-center">
                      <span className="font-medium text-foreground">{schedule.day}</span>
                      <span className={`text-muted-foreground font-inter ${schedule.hours === 'Closed' ? 'text-destructive' : ''}`}>
                        {schedule.hours}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-6 p-4 bg-barber-gold/10 rounded-lg">
                  <p className="text-sm text-foreground font-inter">
                    <strong>Note:</strong> We recommend booking in advance to secure your preferred time slot.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Reviews Preview */}
            <Card className="shadow-soft border-border">
              <CardHeader>
                <CardTitle className="font-playfair text-2xl text-foreground">
                  What Our Customers Say
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-l-4 border-barber-gold pl-4">
                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-barber-gold text-barber-gold" />
                      ))}
                    </div>
                    <p className="text-muted-foreground font-inter text-sm mb-2">
                      "Excellent service! Mo really knows his craft. Best haircut I've had in years."
                    </p>
                    <p className="text-xs text-muted-foreground">- James M.</p>
                  </div>
                  <div className="border-l-4 border-barber-gold pl-4">
                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-barber-gold text-barber-gold" />
                      ))}
                    </div>
                    <p className="text-muted-foreground font-inter text-sm mb-2">
                      "Professional, clean, and friendly. Highly recommended!"
                    </p>
                    <p className="text-xs text-muted-foreground">- David L.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div>
            <Card className="shadow-elegant border-border">
              <CardHeader>
                <CardTitle className="font-playfair text-2xl text-foreground">
                  Send Us a Message
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="contact-name" className="text-foreground mb-2 block">
                      Your Name *
                    </Label>
                    <Input
                      id="contact-name"
                      value={contactForm.name}
                      onChange={(e) => setContactForm({...contactForm, name: e.target.value})}
                      placeholder="Enter your name"
                      required
                      className="border-border focus:ring-barber-gold"
                    />
                  </div>

                  <div>
                    <Label htmlFor="contact-email" className="text-foreground mb-2 block">
                      Email Address *
                    </Label>
                    <Input
                      id="contact-email"
                      type="email"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({...contactForm, email: e.target.value})}
                      placeholder="your.email@example.com"
                      required
                      className="border-border focus:ring-barber-gold"
                    />
                  </div>

                  <div>
                    <Label htmlFor="contact-message" className="text-foreground mb-2 block">
                      Message *
                    </Label>
                    <Textarea
                      id="contact-message"
                      value={contactForm.message}
                      onChange={(e) => setContactForm({...contactForm, message: e.target.value})}
                      placeholder="Tell us how we can help you..."
                      rows={6}
                      required
                      className="border-border focus:ring-barber-gold"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-gold text-white text-lg py-6 hover:shadow-gold transition-all duration-300"
                    size="lg"
                  >
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Map Placeholder */}
            <Card className="mt-8 shadow-soft border-border">
              <CardContent className="p-0">
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-barber-gold mx-auto mb-2" />
                    <p className="text-muted-foreground font-inter">
                      Interactive Map<br />
                      <span className="text-sm">Mo Barber Colchester Location</span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;