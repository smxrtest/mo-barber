const Gallery = () => {
  // Placeholder gallery items - these would be replaced with actual photos
  const galleryItems = [
    { id: 1, title: "Classic Gentleman's Cut", category: "haircuts" },
    { id: 2, title: "Modern Fade Style", category: "haircuts" },
    { id: 3, title: "Traditional Wet Shave", category: "shaves" },
    { id: 4, title: "Beard Sculpture", category: "beards" },
    { id: 5, title: "Father & Son Session", category: "family" },
    { id: 6, title: "Special Occasion Style", category: "styling" },
    { id: 7, title: "Vintage Pompadour", category: "haircuts" },
    { id: 8, title: "Professional Trim", category: "beards" },
  ];

  const sidePhotos = [
    { id: 1, title: "Shop Interior", position: "left-top" },
    { id: 2, title: "Barber Tools", position: "right-top" },
    { id: 3, title: "Awards Display", position: "left-bottom" },
    { id: 4, title: "Customer Reviews", position: "right-bottom" },
  ];

  return (
    <section id="gallery" className="py-20 bg-background relative overflow-hidden">
      {/* Side Photo Areas */}
      <div className="absolute left-4 top-20 w-20 h-32 bg-muted rounded-lg shadow-soft flex items-center justify-center">
        <p className="text-xs text-muted-foreground text-center rotate-90">
          Side Photo 1
        </p>
      </div>
      <div className="absolute right-4 top-20 w-20 h-32 bg-muted rounded-lg shadow-soft flex items-center justify-center">
        <p className="text-xs text-muted-foreground text-center rotate-90">
          Side Photo 2
        </p>
      </div>
      <div className="absolute left-4 bottom-20 w-20 h-32 bg-muted rounded-lg shadow-soft flex items-center justify-center">
        <p className="text-xs text-muted-foreground text-center rotate-90">
          Side Photo 3
        </p>
      </div>
      <div className="absolute right-4 bottom-20 w-20 h-32 bg-muted rounded-lg shadow-soft flex items-center justify-center">
        <p className="text-xs text-muted-foreground text-center rotate-90">
          Side Photo 4
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Our <span className="text-barber-gold">Gallery</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-inter">
            Take a look at our exceptional work and see why Mo Barber Colchester 
            is the trusted choice for professional grooming in the area.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {["All", "Haircuts", "Shaves", "Beards", "Styling"].map((filter) => (
            <button
              key={filter}
              className="px-6 py-2 rounded-full border border-border text-foreground hover:bg-barber-gold hover:text-white hover:border-barber-gold transition-all duration-300 font-inter"
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {galleryItems.map((item) => (
            <div
              key={item.id}
              className="aspect-square bg-muted rounded-lg shadow-soft hover:shadow-elegant transition-all duration-300 flex items-center justify-center cursor-pointer group"
            >
              <div className="text-center p-4">
                <div className="w-12 h-12 bg-barber-gold/20 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:bg-barber-gold/40 transition-colors">
                  <div className="w-6 h-6 bg-barber-gold rounded-sm"></div>
                </div>
                <p className="text-sm font-medium text-foreground group-hover:text-barber-gold transition-colors">
                  {item.title}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Photo Placeholder
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4 font-inter">
            Follow us on social media to see more of our work and latest updates!
          </p>
          <div className="flex justify-center gap-6">
            <div className="w-12 h-12 bg-barber-gold/10 rounded-full flex items-center justify-center cursor-pointer hover:bg-barber-gold/20 transition-colors">
              <span className="text-barber-gold font-bold">IG</span>
            </div>
            <div className="w-12 h-12 bg-barber-gold/10 rounded-full flex items-center justify-center cursor-pointer hover:bg-barber-gold/20 transition-colors">
              <span className="text-barber-gold font-bold">FB</span>
            </div>
            <div className="w-12 h-12 bg-barber-gold/10 rounded-full flex items-center justify-center cursor-pointer hover:bg-barber-gold/20 transition-colors">
              <span className="text-barber-gold font-bold">TW</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Gallery;