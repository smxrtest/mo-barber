import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const Services = () => {
  const services = [
    {
      title: "Classic Haircut",
      description: "Traditional and modern cuts tailored to your style and face shape",
      price: "£25",
      duration: "45 mins",
      features: ["Consultation", "Wash & Cut", "Styling", "Hot Towel"]
    },
    {
      title: "Beard Trim & Shape",
      description: "Precision beard trimming and shaping for the perfect look",
      price: "£18",
      duration: "30 mins",
      features: ["Beard Assessment", "Trim & Shape", "Oil Treatment", "Styling"]
    },
    {
      title: "Traditional Wet Shave",
      description: "Classic hot towel shave with premium products for ultimate comfort",
      price: "£22",
      duration: "40 mins",
      features: ["Hot Towel", "Premium Cream", "Straight Razor", "Aftercare"]
    },
    {
      title: "Full Service Package",
      description: "Complete grooming experience with cut, shave, and styling",
      price: "£40",
      duration: "75 mins",
      features: ["Haircut", "Beard Trim", "Hot Shave", "Styling", "Massage"],
      popular: true
    },
    {
      title: "Father & Son",
      description: "Special package for fathers and sons to enjoy together",
      price: "£35",
      duration: "60 mins",
      features: ["2 Haircuts", "Styling", "Father-Son Bonding", "Group Photos"]
    },
    {
      title: "Hair Wash & Style",
      description: "Professional wash and styling service for special occasions",
      price: "£15",
      duration: "25 mins",
      features: ["Deep Cleanse", "Conditioning", "Blow Dry", "Styling"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Our <span className="text-barber-gold">Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-inter">
            From classic cuts to traditional shaves, we offer a full range of professional 
            barbering services to keep you looking sharp and feeling confident.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className={`relative shadow-soft hover:shadow-elegant transition-all duration-300 border-border ${
                service.popular ? 'ring-2 ring-barber-gold' : ''
              }`}
            >
              {service.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-gold text-white">
                  Most Popular
                </Badge>
              )}
              
              <CardHeader className="text-center pb-4">
                <CardTitle className="font-playfair text-2xl text-foreground mb-2">
                  {service.title}
                </CardTitle>
                <div className="flex justify-center items-center gap-4">
                  <span className="text-3xl font-bold text-barber-gold">
                    {service.price}
                  </span>
                  <span className="text-muted-foreground">
                    {service.duration}
                  </span>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-muted-foreground mb-6 font-inter text-center">
                  {service.description}
                </p>
                
                <div className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center">
                      <div className="w-2 h-2 bg-barber-gold rounded-full mr-3"></div>
                      <span className="text-foreground font-inter text-sm">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>
                
                <Button 
                  className="w-full bg-gradient-gold text-white hover:shadow-gold transition-all duration-300"
                >
                  Book This Service
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-6 font-inter">
            Can't find what you're looking for? We offer custom services tailored to your needs.
          </p>
          <Button 
            variant="outline" 
            size="lg"
            className="border-barber-gold text-barber-gold hover:bg-barber-gold hover:text-white transition-all duration-300"
          >
            Contact Us for Custom Service
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Services;