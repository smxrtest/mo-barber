import { Card, CardContent } from "@/components/ui/card";
import { Scissors, Award, Users, Clock } from "lucide-react";

const About = () => {
  const features = [
    {
      icon: Scissors,
      title: "Expert Craftsmanship",
      description: "Precision cuts and styling with years of experience"
    },
    {
      icon: Award,
      title: "Premium Quality",
      description: "Only the finest products and tools for exceptional results"
    },
    {
      icon: Users,
      title: "Personalized Service",
      description: "Tailored grooming experience for every client"
    },
    {
      icon: Clock,
      title: "Convenient Hours",
      description: "Flexible scheduling to fit your busy lifestyle"
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            About <span className="text-barber-gold">Mo Barber</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-inter">
            Welcome to Mo Barber Colchester, where traditional barbering meets modern style. 
            Our team of experienced barbers is dedicated to providing top-quality grooming services 
            in a comfortable and welcoming environment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <Card key={index} className="text-center p-6 shadow-soft hover:shadow-elegant transition-all duration-300 border-border">
              <CardContent className="pt-6">
                <feature.icon className="h-12 w-12 text-barber-gold mx-auto mb-4" />
                <h3 className="font-playfair text-xl font-semibold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground font-inter">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-card rounded-lg p-8 shadow-elegant">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="font-playfair text-3xl font-bold text-foreground mb-6">
                Meet Mo - Master Barber & Owner
              </h3>
              <p className="text-muted-foreground mb-6 font-inter leading-relaxed">
                With over a decade of experience in the barbering industry, Mo has built a reputation 
                for excellence in Colchester. His passion for the craft and attention to detail ensures 
                every client leaves looking and feeling their absolute best.
              </p>
              <p className="text-muted-foreground mb-6 font-inter leading-relaxed">
                Mo specializes in classic cuts, modern styles, traditional wet shaves, and precise beard sculpting. 
                His commitment to customer satisfaction and professional service has made Mo Barber Colchester 
                a trusted name in the community.
              </p>
              <div className="flex flex-wrap gap-4">
                <span className="bg-barber-gold/10 text-barber-gold px-3 py-1 rounded-full text-sm font-medium">
                  10+ Years Experience
                </span>
                <span className="bg-barber-gold/10 text-barber-gold px-3 py-1 rounded-full text-sm font-medium">
                  Certified Professional
                </span>
                <span className="bg-barber-gold/10 text-barber-gold px-3 py-1 rounded-full text-sm font-medium">
                  Award Winner
                </span>
              </div>
            </div>
            <div className="bg-muted rounded-lg h-80 flex items-center justify-center">
              <p className="text-muted-foreground font-inter text-center">
                Mo's Professional Photo<br />
                <span className="text-sm">(Photo placement area)</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;