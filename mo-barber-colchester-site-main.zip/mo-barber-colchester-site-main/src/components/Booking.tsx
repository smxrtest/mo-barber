import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, User, Phone, Mail, Scissors } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Booking = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    date: "",
    time: "",
    notes: ""
  });

  const services = [
    "Classic Haircut - £25",
    "Beard Trim & Shape - £18", 
    "Traditional Wet Shave - £22",
    "Full Service Package - £40",
    "Father & Son - £35",
    "Hair Wash & Style - £15"
  ];

  const timeSlots = [
    "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
    "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM", "2:00 PM", "2:30 PM",
    "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM", "5:00 PM", "5:30 PM"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Booking Request Submitted!",
      description: "Thank you! We'll contact you shortly to confirm your appointment.",
    });
    // Reset form
    setFormData({
      name: "",
      email: "",
      phone: "",
      service: "",
      date: "",
      time: "",
      notes: ""
    });
  };

  return (
    <section id="booking" className="py-20 bg-gradient-section">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Book Your <span className="text-barber-gold">Appointment</span>
          </h2>
          <p className="text-xl text-muted-foreground font-inter">
            Ready for the perfect cut? Schedule your appointment today and experience 
            professional barbering at its finest.
          </p>
        </div>

        <Card className="shadow-elegant border-border">
          <CardHeader className="text-center">
            <CardTitle className="font-playfair text-2xl text-foreground">
              Schedule Your Visit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name" className="flex items-center gap-2 text-foreground mb-2">
                    <User className="h-4 w-4" />
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter your full name"
                    required
                    className="border-border focus:ring-barber-gold"
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="flex items-center gap-2 text-foreground mb-2">
                    <Phone className="h-4 w-4" />
                    Phone Number *
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder="Your phone number"
                    required
                    className="border-border focus:ring-barber-gold"
                  />
                </div>

                <div>
                  <Label htmlFor="email" className="flex items-center gap-2 text-foreground mb-2">
                    <Mail className="h-4 w-4" />
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="your.email@example.com"
                    required
                    className="border-border focus:ring-barber-gold"
                  />
                </div>

                <div>
                  <Label className="flex items-center gap-2 text-foreground mb-2">
                    <Scissors className="h-4 w-4" />
                    Service *
                  </Label>
                  <Select value={formData.service} onValueChange={(value) => setFormData({...formData, service: value})}>
                    <SelectTrigger className="border-border focus:ring-barber-gold">
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service} value={service}>
                          {service}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="date" className="flex items-center gap-2 text-foreground mb-2">
                    <Calendar className="h-4 w-4" />
                    Preferred Date *
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                    required
                    className="border-border focus:ring-barber-gold"
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>

                <div>
                  <Label className="flex items-center gap-2 text-foreground mb-2">
                    <Clock className="h-4 w-4" />
                    Preferred Time *
                  </Label>
                  <Select value={formData.time} onValueChange={(value) => setFormData({...formData, time: value})}>
                    <SelectTrigger className="border-border focus:ring-barber-gold">
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="notes" className="text-foreground mb-2 block">
                  Special Requests or Notes
                </Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  placeholder="Any special requests or notes for your appointment..."
                  rows={4}
                  className="border-border focus:ring-barber-gold"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-gradient-gold text-white text-lg py-6 hover:shadow-gold transition-all duration-300"
                size="lg"
              >
                Submit Booking Request
              </Button>

              <p className="text-center text-sm text-muted-foreground font-inter">
                * We'll contact you within 24 hours to confirm your appointment time and date.
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default Booking;