import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Volume2, Maximize } from "lucide-react";

const VideoSection = () => {
  return (
    <section className="py-20 bg-gradient-section">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Experience <span className="text-barber-gold">Mo Barber</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-inter">
            Get a behind-the-scenes look at our barbershop, meet the team, 
            and see the artistry that goes into every cut and shave.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Main Video Player */}
          <Card className="shadow-elegant border-border overflow-hidden">
            <CardHeader className="pb-4">
              <CardTitle className="font-playfair text-2xl text-foreground text-center">
                Barbershop Tour & Services
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="relative aspect-video bg-barber-charcoal flex items-center justify-center group cursor-pointer">
                {/* Video Placeholder */}
                <div className="absolute inset-0 bg-gradient-hero opacity-80"></div>
                <div className="relative z-10 text-center text-white">
                  <div className="w-20 h-20 bg-barber-gold rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Play className="h-8 w-8 text-white ml-1" />
                  </div>
                  <p className="text-lg font-medium mb-2">Watch Our Story</p>
                  <p className="text-sm text-gray-300">3:45 minutes</p>
                </div>
              </div>
              
              {/* Video Controls */}
              <div className="bg-card p-4 border-t border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Button size="sm" variant="ghost" className="text-foreground">
                      <Play className="h-4 w-4 mr-2" />
                      Play
                    </Button>
                    <Button size="sm" variant="ghost" className="text-foreground">
                      <Volume2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button size="sm" variant="ghost" className="text-foreground">
                    <Maximize className="h-4 w-4" />
                  </Button>
                </div>
                <div className="mt-3">
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-barber-gold h-2 rounded-full w-1/3"></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Featured Videos List */}
          <div className="space-y-6">
            <Card className="shadow-soft border-border">
              <CardContent className="p-6">
                <h3 className="font-playfair text-xl font-semibold text-foreground mb-4">
                  Featured Videos
                </h3>
                
                <div className="space-y-4">
                  {[
                    { title: "The Art of Traditional Wet Shaving", duration: "2:30", views: "1.2K" },
                    { title: "Modern Fade Techniques", duration: "3:15", views: "856" },
                    { title: "Beard Styling Masterclass", duration: "4:20", views: "2.1K" },
                    { title: "Customer Testimonials", duration: "1:45", views: "634" }
                  ].map((video, index) => (
                    <div key={index} className="flex items-center gap-4 p-3 rounded-lg hover:bg-accent transition-colors cursor-pointer">
                      <div className="w-16 h-12 bg-barber-gold/20 rounded flex items-center justify-center">
                        <Play className="h-4 w-4 text-barber-gold" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-foreground text-sm mb-1">
                          {video.title}
                        </h4>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span>{video.duration}</span>
                          <span>•</span>
                          <span>{video.views} views</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-soft border-border">
              <CardContent className="p-6">
                <h3 className="font-playfair text-xl font-semibold text-foreground mb-4">
                  Why Choose Mo Barber?
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-barber-gold rounded-full"></div>
                    <span className="text-foreground font-inter text-sm">10+ years of professional experience</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-barber-gold rounded-full"></div>
                    <span className="text-foreground font-inter text-sm">Premium quality products and tools</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-barber-gold rounded-full"></div>
                    <span className="text-foreground font-inter text-sm">Personalized service for every client</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-barber-gold rounded-full"></div>
                    <span className="text-foreground font-inter text-sm">Clean, welcoming environment</span>
                  </div>
                </div>
                
                <Button className="w-full mt-6 bg-gradient-gold text-white hover:shadow-gold transition-all duration-300">
                  Book Your Appointment
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VideoSection;