import { MapPin, Phone, Mail, Clock } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-barber-dark text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Business Info */}
          <div>
            <h3 className="font-playfair text-2xl font-bold mb-4">
              Mo<span className="text-barber-gold">Barber</span>
            </h3>
            <p className="text-gray-300 mb-4 font-inter">
              Experience the art of barbering at Mo Barber Colchester. 
              Professional grooming services in a welcoming environment.
            </p>
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-barber-gold/20 rounded-full flex items-center justify-center cursor-pointer hover:bg-barber-gold/30 transition-colors">
                <span className="text-barber-gold font-bold text-sm">IG</span>
              </div>
              <div className="w-10 h-10 bg-barber-gold/20 rounded-full flex items-center justify-center cursor-pointer hover:bg-barber-gold/30 transition-colors">
                <span className="text-barber-gold font-bold text-sm">FB</span>
              </div>
              <div className="w-10 h-10 bg-barber-gold/20 rounded-full flex items-center justify-center cursor-pointer hover:bg-barber-gold/30 transition-colors">
                <span className="text-barber-gold font-bold text-sm">TW</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-playfair text-lg font-semibold mb-4 text-barber-gold">
              Quick Links
            </h4>
            <ul className="space-y-2 font-inter">
              <li><a href="#home" className="text-gray-300 hover:text-barber-gold transition-colors">Home</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-barber-gold transition-colors">About</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-barber-gold transition-colors">Services</a></li>
              <li><a href="#gallery" className="text-gray-300 hover:text-barber-gold transition-colors">Gallery</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-barber-gold transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-playfair text-lg font-semibold mb-4 text-barber-gold">
              Our Services
            </h4>
            <ul className="space-y-2 font-inter">
              <li><span className="text-gray-300">Classic Haircuts</span></li>
              <li><span className="text-gray-300">Beard Trimming</span></li>
              <li><span className="text-gray-300">Traditional Shaves</span></li>
              <li><span className="text-gray-300">Hair Styling</span></li>
              <li><span className="text-gray-300">Father & Son Packages</span></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-playfair text-lg font-semibold mb-4 text-barber-gold">
              Contact Info
            </h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-barber-gold mt-0.5" />
                <span className="text-gray-300 font-inter text-sm">
                  High Street, Colchester<br />Essex, CO1 1AA
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-barber-gold" />
                <span className="text-gray-300 font-inter text-sm">+44 1206 123456</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-barber-gold" />
                <span className="text-gray-300 font-inter text-sm">info@mobarbercolchester.co.uk</span>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-barber-gold mt-0.5" />
                <span className="text-gray-300 font-inter text-sm">
                  Mon-Wed: 9AM-6PM<br />
                  Thu-Fri: 9AM-7PM<br />
                  Sat: 8AM-5PM<br />
                  Sun: Closed
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-barber-gold/20 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 font-inter text-sm">
              © 2024 Mo Barber Colchester. All rights reserved.
            </p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-barber-gold text-sm font-inter transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-barber-gold text-sm font-inter transition-colors">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;